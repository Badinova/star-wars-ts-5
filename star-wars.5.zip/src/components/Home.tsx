import Hero from "./Hero.tsx";
import DreamTeam from "./DreamTeam.tsx";
import FarGalaxy from "./FarGalaxy.tsx";
import {characters, defaultHero} from "../utils/constants.ts";
import {useParams} from "react-router";
import {useContext, useEffect} from "react";
import {SWContext} from "../utils/context.ts";
import ErrorPage from "./ErrorPage.tsx";

const Home = () => {

    let {heroId = defaultHero} = useParams();
    const {changeHero} = useContext(SWContext);

    if (!characters[heroId]) {
        return <ErrorPage />;
    }


    useEffect(() => {
        if (!characters[heroId]) {
            heroId = defaultHero;
        }
        changeHero(heroId);
    }, [heroId]);

    return (
        <main className="clearfix">
            <Hero/>
            <DreamTeam/>
            <FarGalaxy/>
        </main>
    );
};

export default Home;